#ifndef BOARD_H
#define BOARD_H

#include <stdio.h>
#include <stdlib.h>
#include "TileList.h"



typedef struct{
  int row;
  int col;
  Tile* tile;
}Cell;

//--------------------------------------------------------
// row : integer , represents the cells row
// col : integer , , represents the cells column
// tile : a struct(character and color)
// return value : a new struct cell(row,col,tile)
// This function returns a new struct cell with the specified column, row and tile

Cell B_newCell(int row, int col,Tile* tile);

//--------------------------------------------------------
// nb_rows : integer , represents the boards row
// nb_cols : integer , represents the boards column
// board[][nb_cols] : 2d array of struct cells
// return value : none
// Side effect : This function initializes a new 2d array of struct cells

void B_initialize(int nb_rows,int nb_cols,Cell board[][nb_cols]);

//--------------------------------------------------------
// nb_rows : integer , represents the boards row
// nb_cols : integer , represents the boards column
// board[][nb_cols] : 2d array of struct cells
// return value : none
// Side effect : This function prints all elements in 2d array of struct Cell

void B_show(int nb_rows,int nb_cols,Cell board[][nb_cols]);

//--------------------------------------------------------
// nb_rows : integer , represents the boards row
// nb_cols : integer , represents the boards column
// cell_row: integer , represents the row of cell
// cell_col: integer , represents the column of cell
// return value : integer
// This function checks If the designated cell (row, column) belong to 2d array of cells or not
// if yes, returns 1 , otherwise 0

int B_belongToBoard(int nb_rows,int nb_cols,int cell_row,int cell_col);

//--------------------------------------------------------
// nb_rows : integer , represents the boards row
// nb_cols : integer , represents the boards column
// cell_row: integer , represents the row of cell
// cell_col: integer , represents the column of cell
// board[][nb_cols] : 2d array of struct cells
// return value : integer
// This function checks If the designated cell (row, column) is not in 2d array of cells
// if yes, returns 1 , otherwise 0

int B_CellIsEmpty(int nb_rows,int nb_cols,Cell board[][nb_cols],int cell_row, int cell_col);

//--------------------------------------------------------
// nb_rows : integer , represents the boards row
// nb_cols : integer , represents the boards column
// cell_row: integer , represents the row of cell
// cell_col: integer , represents the column of cell
// board[][nb_cols] : 2d array of struct cells
// side effect : This function adds the specified cell to the board 

void B_addToBoard(int nb_rows,int nb_cols,Cell board[][nb_cols],Cell cell);

 


#endif

