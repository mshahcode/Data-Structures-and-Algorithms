#include <stdio.h>
#include <ctype.h>
#include <unistd.h>
#include "Board.h"

#define MAX_CAPACITY 255

int main()
{
  srandom(getpid());
  // Stage 3
  
  char name[MAX_CAPACITY];
  char input[MAX_CAPACITY];
  int samples, t,board_row,board_col,cell_row,cell_col,tile_index,temp_int;

  printf("Hello, what is your name? ");
  fgets(name, sizeof(name), stdin);
  if(name[strlen(name)-1] == '\n'){name[strlen(name)-1] = '\0';}   // gets rid of \n
  printf("Dear %s, how many samples of each tile would you like to have ? ", name);
  scanf("%d", &samples);
  getchar();
  TileList *bag = TL_addNTiles(samples);
  TileList *deck = TL_newEmpty();
  for (int i = 0; i < 6; i++){
      deck = TL_addDeck(&bag, deck);  // adding 6 tiles to deck
  }
  printf("Choose the number of rows and columns: ");
  scanf("%d %d",&board_row,&board_col);
  getchar();
  while(board_col<=0 || board_row<=0){
    printf("Column and row must be greater than 0 for board!\n");
    printf("Choose the number of rows and columns: ");
    scanf("%d %d",&board_row,&board_col);
    getchar();
  }
  Cell board[board_row][board_col];
  B_initialize(board_row, board_col, board);
  B_show(board_row, board_col, board);
  TL_show(deck);
  printf("\n");

  while(TL_isEmpty(deck) != 1){
    printf("\nChoose one tile on the deck and its position on the board.\n");
    printf("In this order : tile_index, row, column\t: ");
    fgets(input, sizeof(input), stdin);
    int num_var = sscanf(input, "%d %d %d %d",&tile_index,&cell_row,&cell_col,&temp_int);
    if(num_var != 3 || B_belongToBoard(board_row,board_col,cell_row,cell_col) != 1 || tile_index<0 || tile_index>=TL_size(deck)){
      printf("Wrong user-input or out of index! Enter correct numbers!\n");
      continue;  
    }
    if(B_CellIsEmpty(board_row,board_col,board,cell_row,cell_col) != 1){
      printf("Can't put here tile. Cell is occupied!\n");
      continue;
    }
    TileList* removed = TL_nth(deck,tile_index);
    deck = TL_removetile(deck,removed);
    // add to deck 1 tile, until bag is empty
    if(TL_isEmpty(bag) != 1){
      deck = TL_addDeck(&bag,deck);      
    }
    Cell cell = B_newCell(cell_row,cell_col,&(removed->tile));
    B_addToBoard(board_row,board_col,board,cell);
    B_show(board_row,board_col,board);
    TL_show(deck);
    printf("\nThere are %d tiles left in the bag.\n",TL_size(bag));
  }

  
  return 0;
}
