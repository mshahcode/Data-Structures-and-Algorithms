#ifndef TILELIST_H
#define TILELIST_H

#include <stdio.h>
#include <stdlib.h>
#include "Tile.h"
#include "Random.h"


typedef struct TileList{
  Tile tile; 
  struct TileList* next;
}TileList;

//--------------------------------------------------------
// parameters: none
// return value : NULL
// This function creates an empty list

TileList* TL_newEmpty();

//--------------------------------------------------------
// bag : a list
// return value : integer, 1 or 0
// This function returns 1 if a list is empty and 0 if it's not

int TL_isEmpty(TileList* bag);

//--------------------------------------------------------
// bag : a list
// preconditions: a bag must not be empty
// if a bag is empty, the program stops
// return value : none
// Side effect : This function prints all the elements in a list

void TL_show(TileList* bag); 

//--------------------------------------------------------
// bag : a list
// tile : a struct(character and color)
// return value : a pointer to new list
// This functions adds a specified element to the beginnig of the list
// and returns the pointer to the new list

TileList* TL_addTileBeginning(TileList* bag,Tile tile);

//--------------------------------------------------------
// bag : a list
// tile : a struct(character with color)
// return value : a pointer to new list
// Side effect : alternates the next addres in the list
// This functions adds a specified element to the end of the list
// and returns the pointer to the new list

TileList* TL_addTileEnd(TileList* bag,Tile tile); 

//--------------------------------------------------------
// bag : a list
// tile : a struct(character with color)
// return value : integer
// This functions returns the index of the specified element in the list

int TL_getIndex(TileList* bag, TileList* tile); 

//--------------------------------------------------------
// n : integer, represents the number of samples
// return value : a pointer to new list
// This functions adds 16*n tiles to the list and returns a pointer to the new list

TileList* TL_addNTiles(int n); // Nth tiles to List

//--------------------------------------------------------
// bag : a list
// return value : integer
// This functions returns the size of the list

int TL_size(TileList* bag); // size of List

//--------------------------------------------------------
// bag : a list
// n : integer, represents the index of Nth element in list
// preconditions : bag should not be empty, size of bag should exceed the n value
// if bag is empty or size of bag is less than n, returns NULL
// return value : a pointer to the Nth element 
// This functions returns the address of the nth element of the list

TileList* TL_nth(TileList* bag, int n); // find Tile in given index

//--------------------------------------------------------
// bag : a list
// precondition: bag should not be empty
// if bag is empty, returns NULL
// return value : a pointer to random element
// This functions returns a random element in the list

TileList* TL_randomNth(TileList* bag);

//--------------------------------------------------------
// bag : a list
// n : integer, represents the index of the element to be deleted
// Precondition : bag should not be empty and size of bag should exceed the n value
// if bag is empty returns NULL or size of bag is less than n, returns the bag(list)
// side effect: alternates the next addres in the element
// return value: an address to new list
// This functions deletes the nth element from the list

TileList* TL_removeNth(TileList* bag, int n);  

//--------------------------------------------------------
// bag : a list
// rtile : a list, the element(tile) which will be removed
// precondition: bag should not be empty and rtile should belong to list
// if bag is empty, returns NULL or if rtile doesn't belong to bag, return bag itself
// side effect: alternates the next addres in the element
// return value: an address to new list
// This functions deletes the specified element form the list

TileList* TL_removetile(TileList* bag,TileList* rtile); 

//--------------------------------------------------------
// bag : a list
// side effect : freeing all the elements in list
// return value : NULL
// This functions deletes all the elements from the list

TileList* TL_removeAll(TileList* bag); 

//--------------------------------------------------------
// bag : a list
// deck : a list
// return value : a pointer to new list
// This functions removes random element from one list and adds it to another list

TileList* TL_addDeck(TileList** bag, TileList* deck); 

#endif // TILELIST_H
