#include "Board.h"

Cell B_newCell(int row, int col,Tile* tile){
  Cell new_cell;
  new_cell.row = row;
  new_cell.col = col;
  new_cell.tile = tile;
  return new_cell;
}

void B_initialize(int nb_rows,int nb_cols,Cell board[][nb_cols]){
  for(int i = 0 ; i < nb_rows ; i++){
    for(int j = 0; j < nb_cols ; j++){
      board[i][j].col = j;
      board[i][j].row = i;
      board[i][j].tile = NULL;
    }
  }
}

void B_show(int nb_rows,int nb_cols,Cell board[][nb_cols]){
  printf("\t");
  for(int i = 0 ; i < nb_rows ; i++){printf("%d ",i);}
  printf("\n");
  for(int i = 0 ; i < nb_rows ; i++){
    printf(" %d\t",i);
    for(int j = 0; j < nb_cols ; j++){
      if(board[i][j].tile == NULL){
        printf("— ");
      }else{
        T_show(*(board[i][j].tile));
      }
    }
    printf("\n");
  }
  printf("\n");
}

int B_belongToBoard(int nb_rows,int nb_cols,int cell_row,int cell_col){
  if(cell_row < nb_rows && cell_col < nb_cols && cell_row >= 0 && cell_col >= 0){
    return 1;
  }
  return 0;
}

int B_CellIsEmpty(int nb_rows,int nb_cols,Cell board[][nb_cols],int cell_row, int cell_col){
  if(board[cell_row][cell_col].tile == NULL){
    return 1;
  }
  return 0;

}

void B_addToBoard(int nb_rows,int nb_cols,Cell board[][nb_cols],Cell cell){
  board[cell.row][cell.col].tile = cell.tile;
}

/*
int B_belongToBoard(int nb_rows,int nb_cols,Cell cell){
  if(cell.row < nb_rows && cell.col < nb_cols && cell.row >= 0 && cell.col >= 0){
    return 1;
  }else{
    return 0;
  }
}
*/