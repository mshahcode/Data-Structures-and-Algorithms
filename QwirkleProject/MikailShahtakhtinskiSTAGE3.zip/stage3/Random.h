#ifndef RANDOM_H
#define RANDOM_H


#include <stdio.h>
#include <stdlib.h>


int random0n(int n);

#endif