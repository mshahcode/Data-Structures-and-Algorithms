#include "TileList.h"


TileList* TL_newEmpty(){
  return NULL;
}

void TL_show(TileList* bag){
  if(TL_isEmpty(bag)){
    printf("Can't show. Empty!\n");
  }else{
    TileList* pf;
    for (pf = bag; pf != NULL; pf = pf->next){
      T_show(pf->tile);
    }
  }
}

int TL_isEmpty(TileList* bag){
  return bag==NULL;
}


TileList* TL_addTileEnd(TileList* bag,Tile tile){
  TileList* pf;
  TileList* new_tile = (TileList*)malloc(sizeof(TileList));
  if(new_tile == NULL){
    printf("Dynamic allocation is failed!\n");
    exit(1);
  }
  new_tile->tile = tile;
  new_tile->next = NULL;
  if(TL_isEmpty(bag)){
    bag = new_tile;
  }else{
    pf = bag;
    while(pf->next!=NULL){
      pf= pf->next;
    }
    pf->next = new_tile;
  }
  return bag;  
}


TileList* TL_addNTiles(int n){
  TileList* new_list = TL_newEmpty();
  unsigned char colors[] = {C_RED,C_GREEN,C_BLUE,C_YELLOW};
  char characters[] = {'A','B','C','D'};
  for(int i = 0 ; i < 4*n ; i++ ){
    for(int j = 0 ; j < 4 ; j++){
        new_list = TL_addTileEnd(new_list,T_newTile(characters[j],colors[i%4]));
    }
  }
  return new_list;
}

int TL_size(TileList* bag){
  TileList* pf = bag;
  int size = 0;
  if(TL_isEmpty(bag)){
    return 0;
  }
  for(pf = bag; pf != NULL; pf = pf->next){
      size++;        
  }
  return size;
}



TileList* TL_nth(TileList* bag, int n){
  int size = TL_size(bag);
  TileList* pf = bag;
  int flag = 0;
  if(TL_isEmpty(bag)){
    return NULL;
  }else if(n==0){
    return pf;
  }else if(size<=n){
    return NULL;
  }
  while(flag<n && pf!=NULL){
    pf = pf->next;
    flag++;
  }
  return pf;

}

TileList* TL_randomNth(TileList* bag){
  if(TL_isEmpty(bag)){
    return NULL;
  }
  return TL_nth(bag,random0n(TL_size(bag)-1));
}

TileList* TL_removetile(TileList* bag, TileList* rtile){
  TileList* pf = bag;
  if(TL_isEmpty(bag)){
    printf("Can't remove a tile. Empty!\n");
    return NULL;
  }else if(bag == rtile){
    return bag->next;
  }
  while(pf!=NULL && pf->next!=rtile){
    pf=pf->next;
  }
  if(pf==NULL){
    printf("Can't remove.Doesn't belong to bag!\n");
    return bag;
  }
  pf->next = rtile->next;
  return bag;
}

TileList* TL_removeAll(TileList* bag){
  for(int i =TL_size(bag)-1;i>=0; i--){
    free(TL_nth(bag,i));
  }
  return NULL;
}

TileList* TL_addDeck(TileList** bag, TileList* deck){
  TileList* removed_tile = TL_randomNth(*bag);
  deck = TL_addTileEnd(deck,removed_tile->tile);
  *bag = TL_removetile(*bag,removed_tile);
  return deck;
}

/*
TileList* TL_addTileBeginning(TileList* bag,Tile tile){
  TileList* new_tile = (TileList*)malloc(sizeof(TileList));
  if(new_tile == NULL){
    printf("Dynamic allocation is failed!\n");
    exit(1);
  }
  new_tile->tile = tile;
  new_tile->next = bag;
  return new_tile;
}
*/

/*
TileList* TL_nth(TileList* bag, int n){
  int size = TL_size(bag);
  TileList* pf = bag;
  TileList* element = NULL;
  if(n==0){
    return bag;
  }
  int flag = 0;
  for(pf = bag; pf != NULL; pf = pf->next){
      if(n==flag){
        element = pf;
        break;
      }
      flag++;       
  }
  return element;
}
*/

/*
TileList* TL_removeNth(TileList* bag, int n){
  int size = TL_size(bag);
  TileList* pf = bag;
  if(TL_isEmpty(bag)){
    printf("Can't remove. Empty!\n");
    return NULL;
  }else if(n==0){
    pf = pf->next;
    return pf;
  }else if(size<=n){
    printf("Out of range index! Can't remove\n");
    return pf;
  }
  TL_nth(pf,n-1)->next = TL_nth(pf,n+1);
  return pf;
}
*/

/*
TileList* TL_addDeck(TileList** bag, TileList* deck){
  int removed = random0n(TL_size(*bag)-1);
  deck = TL_addTileEnd(deck,TL_nth(*bag,removed)->tile);
  *bag = TL_removeNth(*bag,removed);
  return deck;
}
*/

/*
TileList* TL_addDeck(TileList** bag, TileList* deck){
  TileList* removed_tile = TL_randomNth(*bag);
  int index_removed = TL_getIndex(*bag, removed_tile);
  deck = TL_addTileEnd(deck,removed_tile->tile);
  *bag = TL_removeNth(*bag,index_removed);
  return deck;
}
*/



/*
int TL_getIndex(TileList* bag, TileList* tile){
  int count = 0;
  TileList* pf = bag;
  for(pf = bag; pf != NULL; pf = pf->next){
      if(pf==tile){
        break;
      }
      count++;        
  }
  return count;
}
*/