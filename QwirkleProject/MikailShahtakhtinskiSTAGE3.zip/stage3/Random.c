#include "Random.h"


int random0n(int n){
    return random()%(n+1); // [0:n] included
}

