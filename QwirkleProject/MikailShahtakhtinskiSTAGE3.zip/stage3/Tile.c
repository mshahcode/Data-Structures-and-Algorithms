#include "Tile.h"

Tile T_newTile(char letter, unsigned char color)
{
    Tile new_tile;
    new_tile.letter = letter;
    new_tile.color = color;
    return new_tile;
}

void T_show(Tile tile)
{
    C_printChar(tile.letter, tile.color, C_BLACK);
    printf(" ");
}
