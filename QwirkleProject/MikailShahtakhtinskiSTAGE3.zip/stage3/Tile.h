#ifndef TILE_H
#define TILE_H

#include <stdio.h>
#include <stdlib.h>
#include "Color.h"


typedef struct{
  char letter;
  unsigned char color;
}Tile;


//--------------------------------------------------------
// letter : a character 
// color  : an unsigned character
// return value : a new tile ( a Tile)
// This functions creates a new tile with specified letter and color


Tile T_newTile(char letter, unsigned char color);  // creates new Tile

//--------------------------------------------------------
// Tile : struct
// return value : None
// side effet: This function prints letter and color of specified Tile

void T_show(Tile tile);  
 

#endif

