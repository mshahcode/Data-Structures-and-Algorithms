#include "arena.h"

arena A_new(int nb_rows, int nb_cols){
    arena new_arena;
    new_arena.nb_rows=nb_rows;
    new_arena.nb_cols=nb_cols;
    new_arena.grid = (int*)calloc(nb_cols*nb_rows,sizeof(int));
    return new_arena;
}

int A_isInside(struct cell c, struct arena ar){
    if(c.row>=ar.nb_rows || c.col>=ar.nb_cols || c.col<0 || c.row < 0){
        return 0;
    }
    return 1;
}