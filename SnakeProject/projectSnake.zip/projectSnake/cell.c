#include "cell.h"


struct cell C_new(int row, int col){
    struct cell new_cell;
    new_cell.row=row;
    new_cell.col=col;
    return new_cell;
}

void C_print(struct cell c, char*label){
    printf("%s\t: (%d,%d)\n",label,c.row,c.col);
}

void C_printNeighbors(struct cell c){
    C_print(C_new(c.row-1,c.col),"Upper");
    C_print(C_new(c.row+1,c.col),"Lower");
    C_print(C_new(c.row,c.col-1),"Left");
    C_print(C_new(c.row,c.col+1),"Right");
}