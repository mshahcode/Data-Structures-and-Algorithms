#ifndef __CELLLIST_H__
#define __CELLLIST_H__

#include "stdlib.h"

#define CELL_SIZE 1000
#include "cell.h"
#include "ppm.h"
#include "arena.h"

typedef struct cellList{
    int size;
    struct cell cells[CELL_SIZE];
} cellList;

cellList CL_new();

cellList CL_add(cellList cl,struct cell c);

void CL_print(cellList cl, char*label);

struct cell CL_get(cellList cl, int ind);

struct cell CL_random(struct cellList cl);

cellList CL_neighbors(struct cell c,arena ar);

cellList CL_randomPath(struct cell start,arena ar,int L);

void CL_draw(cellList cl, int nb_rows, int nb_cols, char *ppm_name);

void CL_animate(cellList cl, int nb_rows, int nb_cols, char *ppm_name);

cellList CL_removeFirst(cellList cl);





#endif