#include "cellList.h"

cellList CL_new(){
    cellList new_celllist;
    new_celllist.size=0;
    return new_celllist;
}

cellList CL_add(cellList cl,struct cell c){
    cl.cells[cl.size]=c;
    cl.size++;	
    return cl;
}

void CL_print(cellList cl, char*label){
    printf("%s\n",label);
    for(int i = 0 ; i < cl.size;i++){
        printf("%d : (%d,%d)\n",i,cl.cells[i].row,cl.cells[i].col);
    }
}

struct cell CL_get(cellList cl, int ind){
    if(ind<0 || ind>=cl.size){
        printf("Wrong index! (CL_get)\n");
        exit(1);
    }
    return cl.cells[ind];
}

struct cell CL_random(struct cellList cl){
    if(cl.size==0){
        printf("The cellList is empty! (CL_random)\n");
        exit(1);
    }
    return  cl.cells[(int)random()%cl.size];
}

cellList CL_neighbors(struct cell c,arena ar){
    cellList neighbors = CL_new();
	struct cell upper = C_new(c.row-1,c.col);
	struct cell lower = C_new(c.row+1,c.col);
	struct cell left = C_new(c.row,c.col-1);
	struct cell right = C_new(c.row,c.col+1);
	if(ar.grid[ar.nb_cols*upper.row+upper.col]!=1){
		if(A_isInside(upper,ar)){neighbors = CL_add(neighbors,upper);}
	}
	if(ar.grid[ar.nb_cols*lower.row+lower.col]!=1){
		if(A_isInside(lower,ar)){neighbors = CL_add(neighbors,lower);}
	}
	if(ar.grid[ar.nb_cols*left.row+left.col]!=1){
		if(A_isInside(left,ar)){neighbors = CL_add(neighbors,left);}
	}
	if(ar.grid[ar.nb_cols*right.row+right.col]!=1){
		if(A_isInside(right,ar)){neighbors = CL_add(neighbors,right);}
	}
    return neighbors;
}

cellList CL_randomPath(struct cell start,arena ar,int L){
    cellList new_list = CL_new();
	char labelnumber[6];
	int number = 0;
	while(1){
		sprintf(labelnumber,"%d",number);
		ar.grid[start.row*ar.nb_cols+start.col]=1;
        new_list = CL_add(new_list,start);
		if(new_list.size > L){
			ar.grid[new_list.cells[0].row*ar.nb_cols+new_list.cells[0].col] = 0;
			new_list = CL_removeFirst(new_list);
		}
		cellList neighbours = CL_neighbors(start,ar);
		if(neighbours.size==0){
			break;
		}
		CL_draw(new_list,ar.nb_rows,ar.nb_cols,labelnumber);
        start = CL_random(neighbours);
		number++;
    }
    return new_list;
}

void CL_draw(cellList cl, int nb_rows, int nb_cols, char *ppm_name)
{
	int pixels_per_cell = 20;
	char ppm_file_name[50];
	float proportion_serpent = 0.7;
	struct ppm img = PPM_new(nb_rows, nb_cols, pixels_per_cell, proportion_serpent);
	img = PPM_drawBG(img);

	struct cell c = CL_get(cl,0);
	img = PPM_drawCell(img, c.row, c.col);

	for(int i=1; i<cl.size;i++)
	{
		struct cell c = CL_get(cl,i);
		struct cell c2 = CL_get(cl,i-1);
		img = PPM_drawLink(img, c.row, c.col, c2.row, c2.col);
		img = PPM_drawCell(img, c.row, c.col);
	}
	sprintf(ppm_file_name,"%s.ppm",ppm_name);
	PPM_save(img,ppm_file_name);
}

void CL_animate(cellList cl, int nb_rows, int nb_cols, char *ppm_name)
{
	int pixels_per_cell = 20;
	char ppm_file_name[50];
	float proportion_serpent = 0.7;
	struct ppm img = PPM_new(nb_rows, nb_cols, pixels_per_cell, proportion_serpent);
	img = PPM_drawBG(img);

	struct cell c = CL_get(cl,0);
	img = PPM_drawCell(img, c.row, c.col);
	sprintf(ppm_file_name,"%s_%02d.ppm",ppm_name,0);
	PPM_save(img,ppm_file_name);

	for(int i=1; i<cl.size;i++)
	{
		struct cell c = CL_get(cl,i);
		struct cell c2 = CL_get(cl,i-1);
		img = PPM_drawLink(img, c.row, c.col, c2.row, c2.col);
		img = PPM_drawCell(img, c.row, c.col);

		sprintf(ppm_file_name,"%s_%02d.ppm",ppm_name,i);
		PPM_save(img,ppm_file_name);
	}
}

cellList CL_removeFirst(cellList cl){
	for(int i = 0 ; i < cl.size-1;i++){
		cl.cells[i] = cl.cells[i+1];
	}
	cl.size--;
	return cl;
}


