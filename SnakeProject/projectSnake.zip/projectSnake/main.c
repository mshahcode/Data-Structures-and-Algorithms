#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "cellList.h"


int main(){
    srandom(getpid());
    arena new_arena = A_new(10,10);
    cellList cl = CL_randomPath(C_new(0,0),new_arena,10);
    
    
    
    
    return 0;
}