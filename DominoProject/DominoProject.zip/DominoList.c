#include "DominoList.h"

DominoList* DL_new(){
  return NULL;
}

void DL_show(DominoList* dl){
  DominoList* flag;
  for(flag=dl;flag!=NULL;flag=flag->next){
    printf("[%d-%d] ",flag->domino.x,flag->domino.y);
  }
  printf("\n");
}

DominoList* DL_leftInsert(DominoList* dl,Domino domino){
  DominoList* new_list = (DominoList*)malloc(sizeof(DominoList));
  new_list->domino = domino;
  if(DL_isEmpty(dl)){
    new_list->next = NULL;
    return new_list;
  }
  if(DL_canInsertLeft(dl, domino)){
    new_list->next = dl;
    return new_list;
  }
  printf("The value of y of your dominos doesn't match the value of x of the domino in left side!\n");
  return dl;
}


DominoList* DL_rightInsert(DominoList* dl,Domino domino){
  DominoList* flag = dl;
  DominoList* new_list = (DominoList*)malloc(sizeof(DominoList));
  new_list->domino = domino;
  new_list->next = NULL;
  if(DL_isEmpty(dl)){
    return new_list;
  }
  while(flag->next!=NULL){
    flag=flag->next;
  }
  if(DL_canInsertRight(dl, domino)){
    flag->next = new_list;
    return dl;
  }
  printf("The value of x of your dominos doesn't match the value of y of the domino in right side!\n");
  return dl;
}

int DL_isEmpty(DominoList* dl){
  return (dl==NULL);
}

int DL_size(DominoList* dl){
  int count = 0;
  DominoList* flag = dl;
  while(flag!=NULL){
    count++;
    flag = flag->next;
  }
  return count;
}

DominoList* DL_leftDelete(DominoList* dl){
  if(DL_isEmpty(dl)){
    printf("Can not delete from left. List is empty!\n");
    return NULL;
  }
  dl = dl->next;
  return dl;
}

DominoList* DL_rightDelete(DominoList* dl){
  DominoList* flag = dl;
  if(DL_isEmpty(dl)){
    printf("Can not delete from right. List is empty!\n");
    return NULL;
  }
  if(DL_size(dl)==1){
    return NULL;
  }
  while(flag->next->next!=NULL){
    flag = flag->next;
  }
  flag->next=NULL;
  return dl; 
}

Domino DL_leftDomino(DominoList* dl){
  return dl->domino;
}

Domino DL_rightDomino(DominoList* dl){
  DominoList* flag = dl;  
  while(flag->next!=NULL){
    flag=flag->next;
  }
  return flag->domino;
}

int DL_canInsertLeft(DominoList* dl,Domino domino){
  if(DL_leftDomino(dl).x==domino.y){
    return 1;
  }
  return 0;
}

int DL_canInsertRight(DominoList* dl,Domino domino){
  if(DL_rightDomino(dl).y==domino.x){
    return 1;
  }
  return 0;
}