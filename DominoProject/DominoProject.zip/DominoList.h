#ifndef _DOMINOLIST_H_
#define _DOMINOLIST_H_


#include "Domino.h"

typedef struct DominoList{
  Domino domino;
  struct DominoList* next;

} DominoList;

DominoList* DL_new();
void DL_show(DominoList* dl);
DominoList* DL_leftInsert(DominoList* dl,Domino domino);
DominoList* DL_rightInsert(DominoList* dl,Domino domino);
int DL_isEmpty(DominoList* dl);
int DL_size(DominoList *dl);
DominoList* DL_leftDelete(DominoList* dl);
DominoList* DL_rightDelete(DominoList* dl);
Domino DL_leftDomino(DominoList* dl);
Domino DL_rightDomino(DominoList* dl);
int DL_canInsertLeft(DominoList* dl,Domino domino);
int DL_canInsertRight(DominoList* dl,Domino domino);

#endif