#include "Domino.h"

Domino D_new(int x, int y){
  Domino new_domino;
  new_domino.x = x;
  new_domino.y = y;
  return new_domino;
}

void D_show(Domino domino){
  printf("[%d-%d]\n",domino.x,domino.y);
}

int D_leftSide(Domino domino){
    return domino.x;
}

int D_rightSide(Domino domino){
    return domino.y;
}

Domino D_reversed(Domino domino){
    Domino new_domino;
    new_domino.x = domino.y;
    new_domino.y = domino.x;
    return new_domino;
}