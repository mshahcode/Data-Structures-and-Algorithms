#include "DominoList.h"
#include <stdlib.h>
#include <stdio.h>



int main(){
  Domino new_domino = D_new(5, 1);
  Domino reversed = D_reversed(new_domino);
  printf("%d %d\n",D_leftSide(new_domino),D_rightSide(new_domino));
  printf("%d %d\n",D_leftSide(reversed),D_rightSide(reversed));

  DominoList* sl = DL_new();
  sl = DL_rightInsert(sl, D_new(6,1)); 
  sl = DL_rightInsert(sl, D_new(1,3));   
  sl = DL_rightInsert(sl, D_new(3,4));
  DL_show(sl);
  

  return 0;
}