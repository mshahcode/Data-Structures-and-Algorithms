#ifndef _DOMINO_H_
#define _DOMINO_H_

#include <stdio.h>
#include <stdlib.h>

typedef struct{
    int x;
    int y;
} Domino;

Domino D_new(int x, int y);
int D_leftSide(Domino domino);
int D_rightSide(Domino domino);
Domino D_reversed(Domino domino);
void D_show(Domino domino);



#endif