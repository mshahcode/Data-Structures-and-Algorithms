#include <stdio.h>
#include "Playlist.h"

int main(void) {
  Song s1 = S_new("My Mom", "Slim Shady", 5.24f, "Rap",NULL, 0);
  Song s2 = S_new("Most Wanted", "Kizaru", 2.5f, "Rap",NULL, 1);
  Song s3 = S_new("No Role Modelz","J.Cole",4.53f,"Rap",NULL,2);
  Playlist* p_new = P_new("My Rap Musics");
  P_addMusic(p_new, &s1);
  P_addMusic(p_new, &s2);
  P_show(p_new);
  P_addAfter(p_new,&s2,&s3);
  P_show(p_new);
  P_deleteByName(p_new, "No Role Modelz");
  P_show(p_new);
  P_show(p_new);
  P_PlaylistToFile(p_new);

  return 0;
}