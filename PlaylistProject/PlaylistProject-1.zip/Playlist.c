#include "Playlist.h"

Playlist* P_new(char* name){
  Playlist* p_new = (Playlist*)malloc(sizeof(Playlist));
  if(p_new==NULL){
    printf("Dynamic alloction failed!\n");
    exit(1);
  }
  strcpy(p_new->name,name); 
  p_new->first_song=NULL;
  p_new->last_song=NULL;
  p_new->nbSong=0;
  p_new->totalDuration=0.0;
  return p_new;
}

void P_addMusic(Playlist* p,Song* s){
  if(P_isEmpty(p)){
    p->first_song=s;
    p->last_song=s;
  }else{
    Song* pf = p->first_song;
    while(pf->next!=NULL){
      pf=pf->next;
    }
    pf->next=s;
    p->last_song=s;
  }
  p->nbSong+=1;
  p->totalDuration+=s->duration;
}

void P_show(Playlist* p){
  printf("\n\t****************** PLAYLIST: %s ******************\n\n",p->name);
  if(P_isEmpty(p)){
    printf("The playlist is empty!(P_SHOW)\n");
    return;
  }
  Song* pf = p->first_song;
  while(pf!=NULL){
    S_show(pf);
    pf=pf->next;
  }  
  printf("\nTotal number of songs: %d\n",p->nbSong);
  printf("Total duration: %.2f minutes\n\n",p->totalDuration);
}

int P_isEmpty(Playlist* p){
  return (p->first_song==NULL || p->last_song==NULL);
}



void P_addAfter(Playlist* p,Song* after,Song* s){
  if(P_isEmpty(p)){
    printf("The playlist is empty!(P_addAfter)\n");
    return;
  }
  Song* pf = p->first_song;
  while(pf!=after && pf!=NULL){
    pf=pf->next;
  }
  if(pf==NULL){
    printf("There is not such music within this playlist!\n(P_addAfter)\n");
    return;
  }
  if(pf==p->last_song){
    p->last_song=s;
  }
  Song* next = pf->next;
  pf->next=s;
  s->next=next;
  p->nbSong+=1;
  p->totalDuration+=s->duration;
}

void P_deleteByName(Playlist* p,char* name){
  if(P_isEmpty(p)){
    printf("The playlist is empty!(P_deleteByName)\n");
    return;
  }
  Song* pf = p->first_song;
  Song* prev;
  if(strcmp(pf->name,name)==0 && p->nbSong>1){
    p->first_song=p->first_song->next;
    p->totalDuration-=pf->duration;
  }else{
    while(pf!=NULL && strcmp(pf->name, name)!=0){
      prev=pf;
      pf=pf->next;
    }
    if(pf==NULL){printf("There isn't such song with this name (P_deleteByName)\n");return;}
    if(pf==p->last_song){
      p->last_song=prev;
    }
    prev->next=pf->next;
    p->totalDuration-=pf->duration;
  }
  p->nbSong-=1;
}

void P_deleteByID(Playlist* p,int ID){
  if(P_isEmpty(p)){
    printf("The playlist is empty!(P_deleteByID)\n");
    return;
  }
  Song* pf = p->first_song;
  Song* prev;
  if(pf->ID==ID && p->nbSong>=1){
    p->first_song=p->first_song->next;
    p->totalDuration-=pf->duration;
  }else{
    while(pf!=NULL && pf->ID!=ID){
      prev=pf;
      pf=pf->next;
    }
    if(pf==NULL){printf("There isn't such song with this name (P_deleteByName)\n");return;}
    if(pf==p->last_song){
      p->last_song=prev;
    }
    prev->next=pf->next;
    p->totalDuration-=pf->duration;
  }
  p->nbSong-=1;
}

void P_findByName(Playlist* p,char* name){
  if(P_isEmpty(p)){
    printf("The playlist is empty!(P_findByName)\n");
    return;
  }
  Song* pf = p->first_song;
  while(pf!=NULL && strcmp(pf->name, name)!=0){
    pf=pf->next;
  }
  if(pf==NULL){
    printf("There isn't such song with this name (P_findByName)\n");
    return;
  }
  S_show(pf); 
}

void P_findByID(Playlist* p,int ID){
  if(P_isEmpty(p)){
    printf("The playlist is empty!(P_findByName)\n");
    return;
  }
  Song* pf = p->first_song;
  while(pf!=NULL && pf->ID!=ID){
    pf=pf->next;
  }
  if(pf==NULL){
    printf("There isn't such song with this name (P_findByName)\n");
    return;
  }
  S_show(pf); 
}

void P_PlaylistToFile(Playlist* p){
  FILE* fp,*fp2;
  fp = fopen("playlist.csv", "w");
  fp2 = fopen("playlist.txt","w");
  if(P_isEmpty(p)){
    printf("The playlist is empty!(P_SHOW)\n");
    return;
  }
  Song* pf = p->first_song;
  fprintf(fp,"ID, Name, Artist, Genre, Duration\n");
  while(pf!=NULL){
    fprintf(fp,"%d, %s, %s, %s, %.2f\n",pf->ID,pf->name,pf->artist,pf->genre,pf->duration);
    fprintf(fp2,"ID: %d, Name: %s, Actor: %s, Genre: %s, Duration: %.2f\n",pf->ID,pf->name,pf->artist,pf->genre,pf->duration);
    pf=pf->next;
  }  
  fclose(fp);
  fclose(fp2);
}