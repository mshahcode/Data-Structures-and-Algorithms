#include "Song.h"


Song S_new(char* name,char* artist,float duration,char* genre,Song* next,int ID){
  Song new_song;
  strcpy(new_song.name,name);
  strcpy(new_song.artist,artist);
  strcpy(new_song.genre,genre);
  new_song.duration=duration;
  new_song.ID=ID;
  new_song.next=next;
  return new_song;
}

void S_show(Song* s){
  if(s==NULL){
    printf("No such song!(S_SHOW)\n");
    return;
  }
  printf("ID: %d, Name: %s, Artist: %s, Genre: %s, Duration: %.2f\n",s->ID,s->name,s->artist,s->genre,s->duration);
}