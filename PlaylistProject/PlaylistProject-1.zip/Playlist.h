#ifndef __PLAYLIST_H__
#define __PLAYLIST_H__


#include "Song.h"


typedef struct Playlist{
  char name[100];
  Song* first_song;
  Song* last_song;
  int nbSong;
  float totalDuration;
} Playlist;

Playlist* P_new(char* name);
void P_addMusic(Playlist* p,Song* s);
void P_show(Playlist* p);
int P_isEmpty(Playlist* p);
void P_addAfter(Playlist* p,Song* after,Song* s);
void P_deleteByName(Playlist* p,char* name);
void P_deleteByID(Playlist* p,int ID);
void P_findByName(Playlist* p,char* name);
void P_findByID(Playlist* p,int ID);
void P_PlaylistToFile(Playlist* p);
#endif