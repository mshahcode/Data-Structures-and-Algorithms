#ifndef __SONG_H__
#define __SONG_H__


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Song{
  char name[30];
  char artist[60];
  float duration;
  char genre[50];
  struct Song* next;
  int ID;
} Song;

Song S_new(char* name,char* artist,float duration,char* genre,Song* next,int ID);

void S_show(Song* s);











#endif