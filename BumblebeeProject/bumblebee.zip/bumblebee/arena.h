#ifndef __ARENA_H__
#define __ARENA_H__

#include "cell.h"


typedef struct arena{
    int nb_rows;
    int nb_cols;
    int* grid;
} arena;

arena A_new(int nb_rows, int nb_cols);
int A_isInside(struct cell c, struct arena ar);


#endif