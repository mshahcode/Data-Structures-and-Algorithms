#include "cellList.h"
#include <unistd.h>
#include <math.h>




int main(){
    srandom(getpid());
    int nb_rows = 10, nb_cols = 10;
    struct cellList obst = CL_randomFill2(50,nb_rows,nb_cols);
    arena ar= A_new(10,10);
    struct cellList new_cellist = CL_randomFlight(C_new(3,3),15,ar,obst);

    CL_animate2(obst,new_cellist,nb_rows,nb_cols,"bumblebee");





    return 0;
}