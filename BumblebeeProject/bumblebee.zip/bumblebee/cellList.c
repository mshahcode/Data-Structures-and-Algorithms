/*==========================================================*\
  Sunday March the 10th 2019
  Arash Habibi
  CL_draw and CL_animate
\*==========================================================*/


//----------------------------------------------------
// Draws a grid of nb_rows x nb_cols cells in blue,
// and, on this grid, draws the cells of cell list cl.
// The whole image is saved in ppm_name with a .ppm
// extension.

#include "cellList.h"

void CL_draw2(struct cellList cl, int nb_rows, int nb_cols, char *ppm_name)
{
	int pixels_per_cell = 20;
	char ppm_file_name[50];
	float proportion_serpent = 0.5;
	struct ppm img = PPM_new(nb_rows, nb_cols, pixels_per_cell, proportion_serpent);
	img = PPM_drawBG(img);

	for(int i=0; i<cl.size;i++)
	{
		struct cell c = cl.arr[i];
		img = PPM_drawCell(img, c.row, c.col, img.ob_color_r, img.ob_color_g, img.ob_color_b);
	}
	sprintf(ppm_file_name,"%s.ppm",ppm_name);
	PPM_save(img,ppm_file_name);
}

//----------------------------------------------------
// Draws a series of ppm image files. All of them show
// in orange the cells of cell list fix. The first image
// also shows the first cell of cell list anim. The second
// image shows only the second cell of anim and so on.

void CL_animate2(struct cellList fix, struct cellList anim, int nb_rows, int nb_cols, char *ppm_name)
{
	int pixels_per_cell = 20;
	char ppm_file_name[50];
	float proportion_serpent = 0.5;
	struct ppm img = PPM_new(nb_rows, nb_cols, pixels_per_cell, proportion_serpent);
	img = PPM_drawBG(img);

	// img = PPM_drawCell(img, c.row, c.col);

	for(int t=0; t<anim.size;t++)
	{
		img = PPM_drawBG(img);
		for(int i=0; i<fix.size;i++)
		{
			struct cell c = fix.arr[i];
			img = PPM_drawCell(img, c.row, c.col, img.ob_color_r, img.ob_color_g, img.ob_color_b);
		}
		struct cell c = anim.arr[t];
		img = PPM_drawCell(img, c.row, c.col, img.fg_color_r, img.fg_color_g, img.fg_color_b);

		sprintf(ppm_file_name,"%s_%02d.ppm",ppm_name,t);
		PPM_save(img,ppm_file_name);
	}
}

struct cellList CL_new(){
    struct cellList new_celllist;
    new_celllist.size=0;
    return new_celllist;
}

struct cellList CL_add(struct cellList cl,struct cell c){
    cl.arr[cl.size]=c;
    cl.size++;	
    return cl;
}

void CL_print(struct cellList cl, char*label){
    printf("%s\n",label);
    for(int i = 0 ; i < cl.size;i++){
        printf("%d : (%d,%d)\n",i,cl.arr[i].row,cl.arr[i].col);
    }
}

struct cell CL_get(struct cellList cl, int ind){
    if(ind<0 || ind>=cl.size){
        printf("Wrong index! (CL_get)\n");
        exit(1);
    }
    return cl.arr[ind];
}

struct cell CL_random(struct cellList cl){
    if(cl.size==0){
        printf("The cellList is empty! (CL_random)\n");
        exit(1);
    }
    return  cl.arr[(int)random()%cl.size];
}


struct cellList CL_randomFill(int nb_cells, int nb_rows, int nb_cols){
	struct cellList new_cellList = CL_new();
	for(int i = 0 ;i<nb_cells;i++){
		struct cell new_cell = C_new((int)random()%nb_rows,(int)random()%nb_cols);
		new_cellList = CL_add(new_cellList,new_cell);
	}
	return new_cellList;
}


int CL_isInList(struct cell c, struct cellList cl){
	for(int i = 0 ; i < cl.size; i++){
		if(cl.arr[i].col == c.col && cl.arr[i].row == c.row){
			return 1;
		}
	}
	return 0;
}

struct cell CL_randomCellNotInObst(int nb_rows, int nb_cols, struct cellList obst){
	int full = 1;
	for(int i = 0 ; i < nb_rows; i++){
		for(int j = 0 ; j < nb_cols; j++){
			if(!CL_isInList(C_new(i,j),obst)){
				full = 0;
			}
		}
	}
	if(full==1){
		return C_new(-1,-1);
	}
	struct cell new_cell = C_new((int)random()%nb_rows,(int)random()%nb_cols);
	while(CL_isInList(new_cell,obst)){
		new_cell = C_new((int)random()%nb_rows,(int)random()%nb_cols);
	}
	return new_cell;
}

struct cellList CL_randomFill2(int nb_obstacles, int nb_rows, int nb_cols){
	struct cellList new_cellList = CL_new();
	for(int i = 0; i < nb_obstacles; i++){
		struct cell new_cell = CL_randomCellNotInObst(nb_rows,nb_cols,new_cellList);
		if(new_cell.col==-1 || new_cell.row==-1){
			printf("The cellList is full!\n (CL_RANDOMFILL2)\n");
			return CL_new();
		}
		new_cellList = CL_add(new_cellList,new_cell);
	}
	return new_cellList;
}

struct cellList CL_neighbors(struct cell c, struct arena ar){
	struct cellList new_cellList = CL_new();
	struct cell upper = C_new(c.row-1,c.col);
	struct cell up_l = C_new(c.row-1,c.col-1);
	struct cell up_r = C_new(c.row-1,c.col+1);
	struct cell lower = C_new(c.row+1,c.col);
	struct cell lo_l = C_new(c.row+1,c.col-1);
	struct cell lo_r = C_new(c.row+1,c.col+1);
	struct cell left = C_new(c.row,c.col-1);
	struct cell right = C_new(c.row,c.col+1);
	
	if(A_isInside(upper,ar)){
		new_cellList = CL_add(new_cellList,upper);
	}
	if(A_isInside(up_l,ar)){
		new_cellList = CL_add(new_cellList,up_l);
	}
	if(A_isInside(up_r,ar)){
		new_cellList = CL_add(new_cellList,up_r);
	}
	if(A_isInside(lower,ar)){
		new_cellList = CL_add(new_cellList,lower);
	}
	if(A_isInside(lo_l,ar)){
		new_cellList = CL_add(new_cellList,lo_l);
	}
	if(A_isInside(lo_r,ar)){
		new_cellList = CL_add(new_cellList,lo_r);
	}
	if(A_isInside(left,ar)){
		new_cellList = CL_add(new_cellList,left);
	}
	if(A_isInside(right,ar)){
		new_cellList = CL_add(new_cellList,right);
	}
	return new_cellList;
}

struct cellList CL_neighborsObst(struct cell c,struct arena ar,struct cellList obst){
	struct cellList new_cellList = CL_new();
	struct cell upper = C_new(c.row-1,c.col);
	struct cell up_l = C_new(c.row-1,c.col-1);
	struct cell up_r = C_new(c.row-1,c.col+1);
	struct cell lower = C_new(c.row+1,c.col);
	struct cell lo_l = C_new(c.row+1,c.col-1);
	struct cell lo_r = C_new(c.row+1,c.col+1);
	struct cell left = C_new(c.row,c.col-1);
	struct cell right = C_new(c.row,c.col+1);
	
	if(!CL_isInList(upper,obst)){
		if(A_isInside(upper,ar) ){new_cellList = CL_add(new_cellList,upper);}
	}
	if(!CL_isInList(up_l,obst)){
		if(A_isInside(up_l,ar) ){new_cellList = CL_add(new_cellList,up_l);}
	}
	if(!CL_isInList(up_r,obst)){
		if(A_isInside(up_r,ar) ){new_cellList = CL_add(new_cellList,up_r);}
	}
	if(!CL_isInList(lower,obst)){
		if(A_isInside(lower,ar) ){new_cellList = CL_add(new_cellList,lower);}
	}
	if(!CL_isInList(lo_l,obst)){
		if(A_isInside(lo_l,ar) ){new_cellList = CL_add(new_cellList,lo_l);}
	}
	if(!CL_isInList(lo_r,obst)){
		if(A_isInside(lo_r,ar) ){new_cellList = CL_add(new_cellList,lo_r);}
	}
	if(!CL_isInList(left,obst)){
		if(A_isInside(left,ar) ){new_cellList = CL_add(new_cellList,left);}
	}
	if(!CL_isInList(right,obst)){
		if(A_isInside(right,ar) ){new_cellList = CL_add(new_cellList,right);}
	}
	return new_cellList;
}

struct cellList CL_randomFlight(struct cell start,int nb_steps,struct arena ar,struct cellList obstacles){
	struct cellList new_cellList = CL_new();
	start = CL_randomCellNotInObst(10,10,obstacles);
	new_cellList = CL_add(new_cellList,start);
	for(int i = 0 ; i < nb_steps ; i ++){
		start = CL_random(CL_neighborsObst(start,ar,obstacles));
		new_cellList = CL_add(new_cellList,start);
	}
	return new_cellList;
}