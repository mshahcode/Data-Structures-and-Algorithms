#ifndef _DIRECTOR_H_
#define _DIRECTOR_H_


#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct{
  char name[50];
  char surname[50];
  int year;
} Director;


Director D_new(char* name, char* surname, int year);
void D_show(Director* D);


#endif