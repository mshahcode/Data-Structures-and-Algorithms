#include "Director.h"

Director D_new(char* name, char* surname, int year){
  Director new_director;
  strcpy(new_director.name, name);
  strcpy(new_director.surname, surname);
  new_director.year=year;
  return new_director;
}

void D_show(Director* D){
  printf("Name: %s %s, born year: %d\n",D->name,D->surname,D->year);
}