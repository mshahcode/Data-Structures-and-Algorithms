#include "Film.h"


void F_show(Film* f){
  if(f==NULL){
    printf("There is no such film!\n");
    return;
  }
  printf("\n********* Film *********\n");
  printf("\nTitle: %s, released year: %d\nDirector: %s %s\n",f->title,f->release,f->director->name,f->director->surname);
  printf("Actors: \n");
  for(int i = 0 ; i < f->nbActors; i++){
    A_show(f->actors[i]);
  }
  printf("\n************************\n");
}

int F_isPlayIn(Film *f,Actor* actor){
  for(int i = 0; i< f->nbActors;i++){
    if(f->actors[i]==actor){
      return 1;
    }
  }
  return 0;
}