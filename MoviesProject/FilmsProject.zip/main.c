#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "VOD.h"

int main(void) {
  Actor a1 = A_new("Mika", "Shah", 2002);
  Actor a2 = A_new("Aydin","Shah",1996);
  Actor a3 = A_new("Konul","Abdullayeva",1971);
  Actor a4 = A_new("Gunduz","Shah",1969);
  Actor a5 = A_new("Devid","Ruvinov",2002);

  Director d1 = D_new("Jennifer", "Lopez", 1970);
  Director d2 = D_new("Stephen","King",1950);
  Director d3 = D_new("Tom","Howks",1961);
  Director d4 = D_new("Leonardo","DiCaprio",1985);

  Film f1 = {"The boss",1994,&d1,{&a1,&a2},2};
  Film f2 = {"Avengers",2000,&d2,{&a1,&a2,&a3,&a4},4};
  Film f3 = {"Baku",2000,&d3,{&a4,&a5},2};
  Film f4 = {"Lupen",2021,&d4,{&a3},1};

  VOD* vd = VD_new();
  vd = VD_addFilm(vd, &f1);
  vd = VD_addFilm(vd, &f2);
  vd = VD_addFilm(vd, &f3);
  vd = VD_addFilm(vd, &f4);
  printf("\n\t\tSHOWING THE DATABASE OF MOVIES:\n");
  VD_show(vd);

  printf("\nThe title of the oldest films is: %s\n",VD_oldFilmTitle(vd));

  int year = 1994;
  printf("\nActors of year %d is/are:\n",year);
  VD_actorsYears(vd, year);

  VOD* new_vd = VD_removeActorFilms(vd, &a5);
  VD_show(new_vd);

  VD_destroy(vd);
  VD_destroy(new_vd);



  return 0;
}