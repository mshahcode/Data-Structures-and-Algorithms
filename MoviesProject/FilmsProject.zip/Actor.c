#include "Actor.h"

Actor A_new(char* name, char* surname, int year){
  Actor new_actor;
  strcpy(new_actor.name, name);
  strcpy(new_actor.surname, surname);
  new_actor.year=year;
  return new_actor;
}

void A_show(Actor* actor){
  printf("Name: %s %s, born year: %d\n",actor->name,actor->surname,actor->year);
}
