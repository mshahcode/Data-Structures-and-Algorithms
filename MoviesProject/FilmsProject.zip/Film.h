#ifndef _FILM_H_
#define _FILM_H_

#define MAX_SIZE 10


#include <stdio.h>
#include <stdlib.h>
#include "Director.h"
#include "Actor.h"

typedef struct {
  char title[50];
  int release;
  Director* director;
  Actor* actors[MAX_SIZE];
  int nbActors;
} Film;

void F_show(Film* f);
int F_isPlayIn(Film *f,Actor* actor);

#endif