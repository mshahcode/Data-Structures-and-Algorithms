#ifndef _ACTOR_H_
#define _ACTOR_H_


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct{
  char name[50];
  char surname[50];
  int year;
} Actor;

void A_show(Actor* actor);
Actor A_new(char* name, char* surname, int year);


#endif