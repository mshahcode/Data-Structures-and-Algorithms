#include "VOD.h"

VOD* VD_new(){
  return NULL;
}

VOD* VD_addFilm(VOD* v,Film* f){
  VOD* new_vod = (VOD*)malloc(sizeof(VOD));
  new_vod->films=f;
  new_vod->next=v;
  return new_vod;
}

void VD_destroy(VOD* v){
  VOD* next = v;
  VOD* pf= v;
  while(pf!=NULL){
    next=pf->next;
    free(pf);
    pf=next;
  }
}

void VD_show(VOD* v){
  if(v==NULL){
    printf("Can't show the database of movies! Its empty!\n");
  }else{
    VOD* pf = v;
    while(pf!=NULL){
      F_show(pf->films);
      pf=pf->next;
    }
  }
}

char* VD_oldFilmTitle(VOD* v){
  VOD* pf = v;
  int min = 100000;
  VOD* minFilm;
  if(v==NULL){
    printf("The database is emtpy! (oldFilm)\n");
    return NULL;
  }
  while(pf!=NULL){
    if(pf->films->release < min){
      minFilm=pf;
      min = pf->films->release;
    }
    pf=pf->next;
  }
  return minFilm->films->title;
}

void VD_actorsYears(VOD* v,int year){
  VOD* pf = v;
  if(v==NULL){
    printf("The database is empty! (actorsYears)\n");
  }else{
    while(pf!=NULL){
      if(pf->films->release==year){
        for(int i = 0 ; i < pf->films->nbActors;i++){
          printf("%s %s\n",pf->films->actors[i]->name,pf->films->actors[i]->surname);
        }
      }
      pf=pf->next;
    }
  }
}

VOD* VD_removeActorFilms(VOD* v, Actor* actor){
  VOD* pf = v;
  VOD* new_vod = VD_new();
  int flag = 0;
  if(v==NULL){
    printf("The database is empty!\n (removeActorFilms)\n");
    return NULL;
  }
  while(pf!=NULL){
    if(F_isPlayIn(pf->films, actor)){
      new_vod = VD_addFilm(new_vod, pf->films);
    }
    pf=pf->next;
  }
  return new_vod;
}
