#ifndef _VOD_H_
#define _VOD_H_



#include <stdio.h>
#include <stdlib.h>
#include "Film.h"

typedef struct VOD {
  Film* films;
  struct VOD* next;
} VOD;

VOD* VD_new();
VOD* VD_addFilm(VOD* v,Film* f);
void VD_destroy(VOD* v);
void VD_show(VOD* v);
char* VD_oldFilmTitle(VOD* v);
void VD_actorsYears(VOD* v,int year);
VOD* VD_removeActorFilms(VOD* v, Actor* actor);


#endif