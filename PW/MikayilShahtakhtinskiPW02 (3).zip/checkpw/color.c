#include <stdio.h>
#include "color.h"

static int clamp(int n);

void C_print(struct color c){
    printf("(%d,%d,%d)\n",c.red,c.green,c.blue);
}

struct color C_new(int r, int g, int b){
    // I modified the function, so when colors are <0 or > 255, it will correct it
    struct color new_color;
    new_color.red=clamp(r);
    new_color.green=clamp(g);
    new_color.blue=clamp(b);
    return new_color;
}

// static
static int clamp(int n){
    // for correcting the interval
    if(n<0){
        return 0;
    }else if(n>255){
        return 255;
    }else{
        return n;
    }
}

struct color C_coeff(struct color c, float coef){
    struct color new_color;
    // using here clamp, because value can be higher than 255
    new_color.red = clamp(c.red*coef);
    new_color.green = clamp(c.green*coef);
    new_color.blue = clamp(c.blue*coef);
    return new_color;
}

struct color C_negative(struct color c){
    struct color new_color;
    new_color.red= clamp(255 - c.red);
    new_color.green = clamp(255 - c.green);
    new_color.blue = clamp(255 - c.blue);
    return new_color;
}

struct color C_permute(struct color c){
    struct color new_color;
    new_color.red = c.green;
    new_color.green = c.blue;
    new_color.blue = c.red;
    return new_color;
}

int C_intensity(struct color c){
    return (clamp(c.red)+clamp(c.green)+clamp(c.blue))/3;
}

struct color C_grayScale(struct color c){
    struct color new_color = {C_intensity(c),C_intensity(c),C_intensity(c)};
    return new_color;
}

struct color C_threshold(struct color c, int th){
    struct color black = {0,0,0};
    struct color white = {255,255,255};
    if(C_intensity(c)>th){
        return white;
    }else{
        return black;
    }
}

int C_areEqual(struct color c1, struct color c2){
    if((c1.red==c2.red) && (c1.green==c2.green) && (c1.blue = c2.blue)){
        return 1;
    }else{
        return 0;
    }
}

struct color C_addCoef(struct color c1, struct color c2, float coef){
    struct color new_color;
    new_color.red = (c1.red + (c2.red*coef));
    new_color.green = (c1.green + (c2.green*coef));
    new_color.blue = (c1.blue + (c2.blue*coef));
    return new_color;
}




