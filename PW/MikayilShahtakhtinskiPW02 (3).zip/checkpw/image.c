#include "image.h"

void I_print (struct color img[], int nb_pixels){
    for(int i = 0 ; i < nb_pixels;i++){
        C_print(img[i]);
    }
}
void I_coef (struct color img[], int nb_pixels, float coef){
    for(int i = 0 ; i < nb_pixels; i++){
        img[i] = C_coeff(img[i],coef);
    }
}

void I_negative (struct color img[], int nb_pixels){
    for(int i = 0 ; i < nb_pixels; i++){
        img[i] = C_negative(img[i]);
    }
}

void I_permute (struct color img[], int nb_pixels){
    for(int i = 0 ; i < nb_pixels; i++){
        img[i] = C_permute(img[i]);
    }
}

void I_grayScale(struct color img[], int nb_pixels){
    for(int i = 0 ; i < nb_pixels; i++){
        img[i] = C_grayScale(img[i]);
    }
}

void I_threshold(struct color img[], int nb_pixels, int th){
   for(int i = 0 ; i < nb_pixels; i++){
        img[i] = C_threshold(img[i],th);
    }

}
void I_compose(struct color img1[], struct color img2[], int nb_pixels,
struct color target){
    for(int i = 0 ; i < nb_pixels ; i++){
        // i am using here areEqual, and case when they are equal (1)
        if(C_areEqual(img1[i],target)==1){
            img1[i] = img2[i];
        }
    }
}

void I_addColor(struct color img[], int nb_pixels, struct color c){
    for(int i = 0 ; i < nb_pixels ; i++){
        // I use addCoef , with coef 1, which means that i will add just 2 colors
        img[i] = C_addCoef(img[i],c,1);
        // for correcting from [0,255]
        img[i] = C_new(img[i].red,img[i].green,img[i].blue);

    }
}

/*
void I_gradient(struct color img_in[], struct color img_out[], int nb_pixels){
    struct color gray = C_new(127,127,127);
    for(int i = 1; i < nb_pixels ; i++){
        img_out[i] = C_addCoef(img_in[i],img_in[i-1],-1.0);
    }
    I_addColor(img_out,nb_pixels,gray); // adding gray to each pixel with I_addColor
    img_out[0] = gray; // setting gray to 0 index of img_out
}
*/



void I_gradient(struct color img_in[], struct color img_out[], int nb_pixels){
    struct color black = C_new(0,0,0);
    for(int i = 1; i < nb_pixels ; i++){
        img_out[i] = C_addCoef(img_in[i],img_in[i-1],-1.0);
    }
    I_addColor(img_out,nb_pixels,C_new(127,127,127)); // adding gray to each pixel with I_addColor
    img_out[0] = black; // setting black to 0 index of img_out 
}



struct color I_average(struct color img[], int nb_pixels, int fromhere,
int nb_pixels_average){
    struct color new_color;
    int r = 0,g = 0,b = 0;
    if(fromhere+nb_pixels_average < nb_pixels){
        for(int i = fromhere; i <=(nb_pixels_average+fromhere-1); i++){
            r += img[i].red;
            g += img[i].green;
            b += img[i].blue;
        }
        new_color = C_new(r/(nb_pixels_average),g/(nb_pixels_average),b/(nb_pixels_average));
    }else{
        // if there are not enough pixels
        for(int i = fromhere ; i < nb_pixels; i++){
            r += img[i].red;
            g += img[i].green;
            b += img[i].blue;
        }
        int remaining = nb_pixels-fromhere;
        new_color = C_new(r/(remaining),g/(remaining),b/(remaining));
    }
    return new_color;
}

void I_motionBlur(struct color img[], struct color img_out[],
int nb_pixels, int strength){
    for(int i = 0 ; i <nb_pixels ; i++){
        img_out[i] = I_average(img,nb_pixels,i,strength);
    }
}







