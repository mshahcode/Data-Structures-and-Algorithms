#include <stdio.h>
#include "color.h"
#include "image.h"
#include "ppm.h"
int main(){
    
    int nbpixels;
    struct ppm p;
    p = PPM_new("merida.ppm");
    nbpixels = PPM_nbPixels(p);
    struct color *img;
    img = PPM_pixels(p);

    struct ppm p2 = PPM_new("forest.ppm"); 
    int nbpixels2 = PPM_nbPixels(p2);
    struct color *img2;
    img2 = PPM_pixels(p2);

    struct color c1 = C_new(10,50,200);
    struct color c2 = C_new(20,50,200);
    struct color c3 = C_new(10,50,200);
    
    int a = C_areEqual(c1,c2);
    int b = C_areEqual(c1,c3);

    printf("Checking C_areEqual:\n");
    printf("If c1 is equal to c2, then 1 else 0: %d\n",a);
    printf("If c1 is equal to c3, then 1 else 0: %d\n",b);
    printf("Checking C_addCoef:\n");
    printf("c2 - c1: ");
    C_print(C_addCoef(c2,c1,-1.0));
    printf("c1 + 0.25*c2: ");
    C_print(C_addCoef(c1,c2,0.25f));

    //Checking I_average
    printf("Checking I_average, when fromhere is 76 and nb_pixels_av is 5: ");
    C_print(I_average(img,nbpixels,76,5));
    printf("Checking I_average, when fromhere+nb_pixels_av higher than size of array: ");
    C_print(I_average(img,nbpixels,76,nbpixels));
    
    /*
    I_negative(img,nbpixels);
    PPM_save(p,img,"images/negative.ppm");

    I_permute(img, nbpixels);
    PPM_save(p,img,"images/permute.ppm");

    I_grayScale(img,nbpixels);
    PPM_save(p,img,"images/grayscale.ppm");

    I_threshold(img,nbpixels,90);
    PPM_save(p,img,"images/threshold.ppm");

    I_coef(img,nbpixels,3.0f);
    PPM_save(p,img,"images/I_coef(3.0f).ppm");
 
    I_compose(img,img2,nbpixels, C_new(0,111,92));
    PPM_save(p, img,"images/compose.ppm");

    struct color img_out[nbpixels];
    I_gradient(img,img_out,nbpixels); 
    PPM_save(p,img_out,"images/gradient.ppm");
    I_gradient(black) and I_gradient(gray) gives the same results

    struct color img_out[nbpixels];
    I_gradient(img,img_out,nbpixels); 
    PPM_save(p,img_out,"images/gradient(black).ppm");

    struct color img_out[nbpixels];
    I_motionBlur(img,img_out,nbpixels,30); 
    PPM_save(p,img_out,"images/motionblur.ppm");  
    */
    return 0;
}
