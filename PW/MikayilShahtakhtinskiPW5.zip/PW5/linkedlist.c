#include "linkedlist.h"

struct floatList *FL_new1(float x)
{
    struct floatList *new_list = (struct floatList *)malloc(sizeof(struct floatList));
    // if dynamic allocation is failed
    if (new_list == NULL)
    {
        printf("Malloc failed\n");
        exit(1);
    }
    else
    {
        new_list->val = x;
        new_list->next = NULL;
    }
    return new_list;
}

void FL_show1(struct floatList *pf, char *label)
{
    printf("%s\t: %p %f %p\n", label, pf, pf->val, pf->next);
}

/*
// WITH WHILE LOOP
void FL_show(struct floatList *plist, char *label)
{
    struct floatList *pf = plist;
    printf("------- Show floatList : %s ---------\n", label);
    while (pf != NULL)
    {
        printf("%p %f %p\n", pf, pf->val, pf->next);
        pf = pf->next;
    }
}
*/

// WITH FOR LOOP
void FL_show(struct floatList *plist, char *label)
{
    struct floatList *pf = plist;
    int count = 0; // for checking the total number of elements in the list
    printf("------- Show floatList : %s ---------\n", label);
    for (pf = plist; pf != NULL; pf = pf->next)
    {
        printf("%d\t: %p %f %p\n", count, pf, pf->val, pf->next);
        count++;
    }
    printf("%d elements in all\n", count);
}

struct floatList *FL_newEmpty()
{
    return NULL;
}

int FL_isEmpty(struct floatList *plist)
{
    return (plist == NULL) ? 1 : 0; // if empty, then 1 , otherwise 0
}

struct floatList *FL_add(struct floatList *plist, float val)
{
    struct floatList *new_list = FL_new1(val);
    new_list->next = plist;
    return new_list;
}

struct floatList *FL_firstInts(int n)
{
    struct floatList *new_list = FL_newEmpty();
    for (int i = 0; i < n; i++)
    {
        new_list = FL_add(new_list, i);
    }
    return new_list;
}
