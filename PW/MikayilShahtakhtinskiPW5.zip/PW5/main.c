#include "linkedlist.h"

int main()
{
    struct floatList *pf1, *pf2, *pf3;

    pf1 = FL_new1(5);
    pf2 = FL_new1(10);
    pf3 = FL_new1(3);

    printf("Checking FL_show1\n");
    FL_show1(pf1, "first");
    FL_show1(pf2, "second");
    FL_show1(pf3, "third");

    // connecting pf1,pf2,pf3
    pf1->next = pf2;
    pf2->next = pf3;
    printf("\n");

    printf("Checking FL_show\n");
    FL_show(pf1, "first list");

    printf("Checking FL_isEmpty\n");
    struct floatList *pf4 = FL_newEmpty();
    printf("List is empty: %d\n", FL_isEmpty(pf4));

    struct floatList *plist;
    plist = FL_newEmpty();
    plist = FL_add(plist, 3);
    plist = FL_add(plist, 5);
    plist = FL_add(plist, 7);
    FL_show(plist, "list made by FL_add");

    struct floatList *ten = FL_firstInts(10);
    FL_show(ten, "10 first integers");

    return 0;
}