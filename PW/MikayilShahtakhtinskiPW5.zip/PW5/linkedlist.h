#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include <stdio.h>
#include <stdlib.h>

struct floatList
{
    float val;
    struct floatList *next;
};

struct floatList *FL_new1(float x);
void FL_show1(struct floatList *pf, char *label);
void FL_show(struct floatList *plist, char *label);
struct floatList* FL_newEmpty();
int FL_isEmpty(struct floatList *plist);
struct floatList* FL_add(struct floatList *plist, float val);
struct floatList* FL_firstInts(int n);


#endif