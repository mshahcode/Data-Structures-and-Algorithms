#include <unistd.h>  // for getpid()
#include "rand.h"
#include "stack.h"

int main()
{   
    // srandom() sets its argument as the seed for a new sequence of pseudo-random integers to be returned by random(). From console
    // getpid() returns the process ID (PID) of the calling process. From console
    srandom(getpid());  //setting the process ID as a seed 
    
    struct stack st;
    st = ST_new(); // creating new stack
    
    ST_print(st);
    printf("size of stack : %d, top is %d\n",ST_size(st),ST_top(st)); // At first, size is 0 and top undefined

    printf("Pushing numbers of TossOneDice:\n");
    for(int i = 0 ; i<20 ; i++){
        st = ST_push(st,tossOfOneDice()); // pushing numbers from 1 to 6
        ST_print(st);
        printf("size of stack : %d, top is %d\n",ST_size(st),ST_top(st));
    }

    printf("\nPopping numbers from stack\n");
    for(int i = 0 ; i<20 ; i++){
        printf("Popping the top element which is %d\n",ST_top(st));
        st = ST_pop(st); // popping numbers from stack
        ST_print(st);
        printf("size of stack : %d, top is %d\n",ST_size(st),ST_top(st));
        
    }

    printf("\nChecking the maximum random number: %d\n", RAND_MAX);
     
    /* 
    // Produces the same results each time
    // adding srandom(getpid()) will fix it
    for(int i = 0 ; i < 20; i++){
        printf("%ld\n",random());
    }
    */
    printf("\n");
    for(int i = 0 ; i < 3 ; i++){
        printf("Random number from 0 to 1 is: %f\n",random01());
       
    }
    printf("\n");

    for(int i = 0 ; i < 3; i++){
        printf("Random number from 0 to given value (5): %f\n",random0n(5));
    }
    printf("\n");

    for(int i = 0 ; i < 3; i++){
        printf("Tossing the %dth dice: %d\n",i+1, tossOfOneDice());
    }
    printf("\n");

    for(int i = 0 ; i < 3; i++){
        printf("The sum of two dices: %d\n", tossOfTwoDice());
    }

    /*
    // Checking the stack from Figure 1(Stack)
    printf("\n");
    struct stack st;
    st = ST_new();
    ST_print(st);
    printf("\nsize of stack : %d, top is %d\n",ST_size(st),ST_top(st));
    printf("Adding 1 to stack\n");
    st = ST_push(st,1);
    ST_print(st);
    printf("\nsize of stack : %d, top is %d\n",ST_size(st),ST_top(st));
    printf("Adding 5 to stack\n");
    st = ST_push(st,5); // size of stack : 2, top is 5
    ST_print(st);
    printf("\nsize of stack : %d, top is %d\n",ST_size(st),ST_top(st));
    printf("Adding 2 to stack\n");
    st = ST_push(st,2); // size of stack : 3, top is 2
    ST_print(st);
    printf("\nsize of stack : %d, top is %d\n",ST_size(st),ST_top(st));
    printf("Adding 7 to stack\n");
    st = ST_push(st,7); // size of stack : 4, top is 7
    ST_print(st);
    printf("\nsize of stack : %d, top is %d\n",ST_size(st),ST_top(st));
    printf("Popping last element\n");
    st = ST_pop(st); // size of stack : 3, top is 2
    ST_print(st);
    printf("\nsize of stack : %d, top is %d\n",ST_size(st),ST_top(st));
    printf("Popping last element\n");
    st = ST_pop(st); // size of stack : 2, top is 5
    ST_print(st);
    printf("\nsize of stack : %d, top is %d\n",ST_size(st),ST_top(st));
    printf("Popping last element\n");
    st = ST_pop(st); // size of stack : 1, top is 1
    ST_print(st);
    printf("\nsize of stack : %d, top is %d\n",ST_size(st),ST_top(st));
    printf("Adding 3 to stack\n");
    st = ST_push(st,3); // size of stack : 2, top is 3
    ST_print(st);
    printf("\nsize of stack : %d, top is %d\n",ST_size(st),ST_top(st));
    printf("Adding 10 to stack\n");
    st = ST_push(st,10); // size of stack : 3, top is 10
    ST_print(st);
    printf("\nsize of stack : %d, top is %d\n",ST_size(st),ST_top(st));
    printf("Popping last element\n");
    st = ST_pop(st); // size of stack : 2, top is 3
    ST_print(st);
    printf("\nsize of stack : %d, top is %d\n",ST_size(st),ST_top(st));
    printf("Popping last element\n");
    st = ST_pop(st); // size of stack : 1, top is 1
    ST_print(st);
    printf("\nsize of stack : %d, top is %d\n",ST_size(st),ST_top(st));
    printf("Popping last element\n");
    st = ST_pop(st); // size of stack : 0, top undefined
    ST_print(st);
    printf("\nsize of stack : %d, top is %d\n",ST_size(st),ST_top(st));
    */
    
    return 0;
}