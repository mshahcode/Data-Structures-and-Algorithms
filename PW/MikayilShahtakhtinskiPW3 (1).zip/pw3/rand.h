#ifndef RAND_H
#define RAND_H


#include <stdio.h>
#include <stdlib.h>


float random01();
float random0n(int n);
int tossOfOneDice();
int tossOfTwoDice();

#endif