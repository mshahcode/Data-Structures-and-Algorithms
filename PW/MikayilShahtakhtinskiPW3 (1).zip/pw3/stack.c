#include "stack.h"

struct stack ST_new(){
    struct stack new_stack;
    new_stack.size = 0;
    return new_stack;
}

void ST_print(struct stack st){
    printf("In Stack: ");
    for(int i = 0; i < st.size; i++){
        printf("%d ",st.arr[i]);
    }
    printf("\n");
}

int ST_size(struct stack st){
    return st.size;
}

struct stack ST_push(struct stack st, int n){
    if(st.size == CAPACITY){
        printf("Impossible to push. The stack is full!\n");
    }else{
        st.arr[st.size++] = n;
    }
    return st;
}

struct stack ST_pop(struct stack st){
    if(st.size == 0){
        printf("Impossible to pop. Stack is empty!\n");
    }else{
        st.size--;
    }
    return st;
}

int ST_top(struct stack st){
    if(st.size == 0){
        printf("Top undefined\n");
        return -1;
    }else{
        int top = st.arr[st.size-1];
        return top;
    }
}
