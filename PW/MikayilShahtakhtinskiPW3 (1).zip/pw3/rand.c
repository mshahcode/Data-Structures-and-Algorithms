#include "rand.h"


float random01(){
    return random()/(float)RAND_MAX;   // [0:1]
}

float random0n(int n){
    return n*random01();  // n * [0:1] =  [0:n]
}

int tossOfOneDice(){
    return (int) (1.0 + random0n(6)); // casting to get int part of float
}

int tossOfTwoDice(){
    return tossOfOneDice()+tossOfOneDice(); // [2:12]
}