#include <stdio.h>
#include <stdlib.h>

int divide(float a, float b, float *q);

int main(){

    float div;
    printf("Divison 365 by 5:\n");
    printf("The diagnosis: %d\n",divide(365,5,&div));
    printf("The answer is : %f\n",div);

    // Checking division by 0
    printf("Division by zero:\n");
    printf("The diagnosis: %d\n",divide(365,0,&div));

    return 0;
}

int divide(float a, float b, float *q){
    if(b==0){
        printf("Impossible to divide!\n");
        return 0;
    }else{
        // assigning value indirection operator *
        *q = a/b;
        return 1;
    }
}