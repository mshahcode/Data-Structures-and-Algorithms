#include "stack.h"

struct stack ST_new(int maxsize){
    struct stack new_stack;
    new_stack._size = 0;
    // dynamic allocation of _array
    new_stack._array = (int*)calloc(maxsize,sizeof(int));
    return new_stack;
}

void ST_print(struct stack st){
    printf("In Stack: ");
    for(int i = 0; i < st._size; i++){
        printf("%d ",*(st._array+i)); // same as st._array[i]
    }
    printf("\n");
}

int ST_size(struct stack st){
    return st._size;
}

struct stack ST_push(struct stack st, int n, int maxsize){
    if(st._size == maxsize){
        printf("Impossible to push. The stack is full!\n");
    }else{
        *(st._array+(st._size)) = n; // same as st._array[st._size]
        st._size++;
    }
    return st;
}

struct stack ST_pop(struct stack st){
    if(st._size == 0){
        printf("Impossible to pop. Stack is empty!\n");
    }else{
        st._size--;
    }
    return st;
}

int ST_top(struct stack st){
    if(st._size == 0){
        printf("Top undefined\n");
        return -1;
    }else{
        return *(st._array+(st._size-1)); // same as st._array[st._size-1]
    }
}
