#ifndef STACK_H
#define STACK_H

#include <stdio.h>
#include <stdlib.h>

//Dynamic Allocation of Stack

struct stack
{
    int _size;
    int *_array;
};

struct stack ST_new(int maxsize);
void ST_print(struct stack);
int ST_size(struct stack st);
struct stack ST_push(struct stack st, int n, int maxsize);
struct stack ST_pop(struct stack st);
int ST_top(struct stack st);

#endif 



