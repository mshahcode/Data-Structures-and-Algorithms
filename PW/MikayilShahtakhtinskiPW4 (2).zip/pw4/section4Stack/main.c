#include "stack.h"
#include <stdio.h>
#include <stdlib.h>


int main()
{   
    int maxsize; // max capacity of Stack
    printf("Enter max size for a stack: ");
    scanf("%d",&maxsize);

    struct stack st;
    st = ST_new(maxsize);

    ST_print(st);
    printf("size of stack : %d, top is %d\n",ST_size(st),ST_top(st));
    printf("Adding 1 to stack\n");
    st = ST_push(st,1,maxsize);
    ST_print(st);
    printf("size of stack : %d, top is %d\n",ST_size(st),ST_top(st));
    printf("Adding 5 to stack\n");
    st = ST_push(st,5,maxsize); // size of stack : 2, top is 5
    ST_print(st);
    printf("size of stack : %d, top is %d\n",ST_size(st),ST_top(st));
    printf("Adding 2 to stack\n");
    st = ST_push(st,2,maxsize); // size of stack : 3, top is 2
    ST_print(st);
    printf("size of stack : %d, top is %d\n",ST_size(st),ST_top(st));
    printf("Adding 7 to stack\n");
    st = ST_push(st,7,maxsize); // size of stack : 4, top is 7
    ST_print(st);
    printf("size of stack : %d, top is %d\n",ST_size(st),ST_top(st));
    printf("Popping last element\n");
    st = ST_pop(st); // size of stack : 3, top is 2
    ST_print(st);
    printf("size of stack : %d, top is %d\n",ST_size(st),ST_top(st));
    printf("Popping last element\n");
    st = ST_pop(st); // size of stack : 2, top is 5
    ST_print(st);
    printf("size of stack : %d, top is %d\n",ST_size(st),ST_top(st));
    printf("Popping last element\n");
    st = ST_pop(st); // size of stack : 1, top is 1
    ST_print(st);
    printf("size of stack : %d, top is %d\n",ST_size(st),ST_top(st));
    printf("Adding 3 to stack\n");
    st = ST_push(st,3,maxsize); // size of stack : 2, top is 3
    ST_print(st);
    printf("size of stack : %d, top is %d\n",ST_size(st),ST_top(st));
    printf("Adding 10 to stack\n");
    st = ST_push(st,10,maxsize); // size of stack : 3, top is 10
    ST_print(st);
    printf("size of stack : %d, top is %d\n",ST_size(st),ST_top(st));
    printf("Popping top element\n");
    st = ST_pop(st); // size of stack : 2, top is 3
    ST_print(st);
    printf("size of stack : %d, top is %d\n",ST_size(st),ST_top(st));
    printf("Popping top element\n");
    st = ST_pop(st); // size of stack : 1, top is 1
    ST_print(st);
    printf("size of stack : %d, top is %d\n",ST_size(st),ST_top(st));
    printf("Popping top element\n");
    st = ST_pop(st); // size of stack : 0, top undefined
    ST_print(st);
    printf("size of stack : %d, top is %d\n",ST_size(st),ST_top(st));

    free(st._array); // freeing memory
    return 0;
}