#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
    if(argc!=4){
        printf("Wrong number of inputs!\n");
    }else{
        float a = atof(argv[1]); // argv[1] = first operand
        float b = atof(argv[3]); // argv[3] = second operand
        char c = **(argv+2); // the 0th character of argv[2], operator
        switch (c)
        {
        case '+':
            printf("%f + %f = %f\n",a,b,(a+b));
            break;
        
        case '-':
            printf("%f - %f = %f\n",a,b,(a-b));
            break;

        case 'x':
            printf("%f * %f = %f\n",a,b,(a*b));
            break;

        case '/':
            printf("%f / %f = %f\n",a,b,(a/b));
            break;

        default:
            printf("Enter correct operator!\n");
            break;
        }

    }
    
    return 0;
    
}