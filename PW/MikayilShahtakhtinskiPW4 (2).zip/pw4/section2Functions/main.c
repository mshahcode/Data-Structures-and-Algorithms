#include <stdio.h>
#include <stdlib.h>


float* V_new1(float x,float y,float z){
    //datas and arrays statically allocated in functions are destroyed when we call the function. Segmentation fault
    // Dynamic allocation of thenew array remains accessible, after the run of the function
    float* thenew = (float *)calloc(3,sizeof(float));
    thenew[0] = x;
    thenew[1] = y;
    thenew[2] = z;
    return thenew;
}

struct vector { float x,y,z; };

struct vector V_new2(float x,float y,float z){
    struct vector thenew;
    thenew.x = x;
    thenew.y = y;
    thenew.z = z;
    return thenew;
}




int main(){

    float *v1 = V_new1(5,6,7);
    struct vector v2 = V_new2(1,2,3);
    printf("v1 : (%f,%f,%f)\n",v1[0],v1[1],v1[2]);
    printf("v2 : (%f,%f,%f)\n",v2.x, v2.y, v2.z);
    free(v1);
    return 0;


}