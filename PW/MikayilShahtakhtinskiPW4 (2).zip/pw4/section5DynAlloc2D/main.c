#include <stdio.h> 
#include <stdlib.h>

float** DynAlloc2D(int n,int m){
    float **arr = (float**)calloc(m,sizeof(float*));
    for(int i = 0 ; i < m ; i++){
        arr[i] = (float*)calloc(n,sizeof(float));
    }
    return arr;
}

void fillIn(float **grid, int n, int m){
    for(int i = 0 ; i < n ; i++){
        for(int j = 0 ; j < m; j++){
            *(*grid + i*m + j) = i+j;; // same as (*grid)[i*m+j] = i+j
        }
    }
}


void print(float **grid, int n, int m){
    for(int i = 0 ; i < n ; i++){
        for(int j = 0 ; j < m; j++){
            printf("%f  ", (*grid)[i*m+j]); 
        }
        printf("\n");
    }
}
  
int main() { 
   int m,n;

   printf("Enter width of the array: ");
   scanf("%d",&n);
   printf("Enter height of the array: ");
   scanf("%d",&m);

   float **arr;
   arr = DynAlloc2D(n,m);
   fillIn(arr,n,m);
   print(arr,n,m);

   free(arr); // freeing memory 
   
   return 0; 
}