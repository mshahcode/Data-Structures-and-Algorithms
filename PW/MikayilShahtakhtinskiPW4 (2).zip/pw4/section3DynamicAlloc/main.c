#include <stdio.h>
#include <stdlib.h>


int main(){
    int *arr1;
    char *arr2;

    arr1 = (int*)calloc(5,sizeof(int));
    arr2 = (char*)calloc(7,sizeof(char));

    // freeing memory
    free(arr1);
    free(arr2);
    return 0;

}