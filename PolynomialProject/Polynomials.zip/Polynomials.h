#ifndef _POLYNOMIALS_H_
#define _POLYNOMIALS_H_


#include <stdio.h>
#include <stdlib.h>


typedef struct Polynomial{
  int power;
  float coeff;
  struct Polynomial* next;
} Polynomial;

Polynomial* P_new();
Polynomial* P_destroy(Polynomial* p);
void P_display(Polynomial* p);
int P_isNULL(Polynomial* p);
Polynomial* P_addMonominal(Polynomial* p, int power, float coeff);
Polynomial* P_removeNullMon(Polynomial* p);
Polynomial* P_canonical(Polynomial* p);
Polynomial* P_addPolynomial(Polynomial *p1, Polynomial* p2);




#endif