#include "Polynomials.h"


Polynomial* P_new(){
  Polynomial* new_pol = (Polynomial*)malloc(sizeof(Polynomial));
  new_pol->coeff=0.0;
  new_pol->power=0;
  new_pol->next=NULL;
  return new_pol;
}

Polynomial* P_destroy(Polynomial* p){
  Polynomial* pf = p;
  Polynomial* next;
  while(pf!=NULL){
    next=pf->next;
    free(pf);
    pf=next;
  }
  return NULL;
}

void P_display(Polynomial* p){
  while(p!=NULL){
    printf("-->(%.1f X %d)",p->coeff,p->power);
    p=p->next;
  }
  printf("--E\n");
}

int P_isNULL(Polynomial* p){
  if(p->power==0 && p->coeff==0.0 && p->next==NULL){
    return 1;
  }
  return 0;
}


Polynomial* P_addMonominal(Polynomial* p, int power, float coeff){
  Polynomial* p_new = P_new();
  Polynomial* pf = p;
  int flag = 1;
  p_new->power=power;
  p_new->coeff=coeff;
  if(P_isNULL(p) && power == 0 && coeff == 0.0){
    return p;
  }
  while(pf!=NULL){
    if(pf->power==power){
      pf->coeff+=coeff;
      flag=0;
    }
    pf=pf->next;
  }
  if(flag==0){
    return p;
  }
  p_new->next=p;
  return p_new;
}

Polynomial* P_removeNullMon(Polynomial* p){
  Polynomial* prev;
  Polynomial* next;
  if(p->coeff==0){
    p=p->next;
  }
  Polynomial* pf = p;
  while(pf!=NULL){
    next=pf->next;
    if(pf->coeff==0.0){
      prev->next=next;
    }else{
      prev=pf;
    }
    pf=next;
  }
  return p;
}

Polynomial* P_canonical(Polynomial* p){
  if(p==NULL || P_isNULL(p)){
    return NULL;
  }
  Polynomial* current = p;
  Polynomial* next;
  for(current=p;current!=NULL;current=current->next){
    for(next=current->next;next!=NULL;next=next->next){
      if(current->power < next->power){
        int flag = current->power;
        current->power = next->power;
        next->power = flag;
        int flag2 = current->coeff;
        current->coeff = next->coeff;
        next->coeff = flag2;
      }  
    }
  }
  return p;
}

Polynomial* P_addPolynomial(Polynomial *p1, Polynomial* p2){
  Polynomial* p_new = P_new();
  Polynomial* pf1 = p1;
  Polynomial* pf2 = p2;
  while(pf1!=NULL){
    p_new = P_addMonominal(p_new, pf1->power, pf1->coeff);
    pf1=pf1->next;
  }
  while(pf2!=NULL){
    p_new = P_addMonominal(p_new, pf2->power, pf2->coeff);
    pf2=pf2->next;
  }
  p_new = P_removeNullMon(p_new);
  p_new = P_canonical(p_new);
  return p_new;
}