#include <stdio.h>
#include <stdlib.h>
#include "Polynomials.h"

int main(void) {

  Polynomial* p_new = P_new();
  p_new = P_addMonominal(p_new, 3,-2.0);
  p_new = P_addMonominal(p_new, 1,4.0);
  p_new = P_addMonominal(p_new, 5,1);
  p_new = P_addMonominal(p_new, -1,25.0);
  p_new = P_addMonominal(p_new, 1,-4.0);
  p_new = P_removeNullMon(p_new);
  p_new = P_canonical(p_new);
  P_display(p_new);

  Polynomial* p_new2 = P_new();
  p_new2 = P_addMonominal(p_new2, 7,10);
  p_new2 = P_addMonominal(p_new2, 3,3);
  p_new2 = P_addMonominal(p_new2, 45,25.0);
  p_new2 = P_removeNullMon(p_new2);
  p_new2 = P_canonical(p_new2);
  P_display(p_new2);
  
  Polynomial* p_new3 = P_addPolynomial(p_new,p_new2);
  P_display(p_new3);

  return 0;
}