#ifndef _ADRESS_H_
#define _ADRESS_H_


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Adress{
  char* name;
  char* surname;
  char* sex;
  int homeNumber;
  int phoneNumber;
  struct Adress* previous;
  struct Adress* next;
} Adress;


void A_show(Adress* a);
Adress* A_new(char* name,char* surname,char* sex,int homeNum,int phoneNum,Adress* previous);
Adress* A_addAdress(Adress* a,Adress* address);
void A_delete(Adress* a);
int A_inDatabase(Adress* a,char *name,char* surname);
Adress* A_inputAdress();
Adress* A_removeAdress(Adress* a,char* name, char* surname);



#endif