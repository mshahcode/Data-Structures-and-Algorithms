#include "Adress.h"

void A_show(Adress* a){
  if(a==NULL){
    printf("\nThe list is empty! Can't show (A_show)\n");
    return;
  }
  Adress* pf = a;
  printf("\n\t\t************Address database***********\n\n");
  while(pf!=NULL){
    printf("Contact: %s %s, sex: %s, home telephone: %d, phone number: %d\n",pf->name,pf->surname,pf->sex,pf->homeNumber,pf->phoneNumber);
    pf=pf->next;
  }
  printf("\n\t\t***************************************\n");
}

Adress* A_new(char* name,char* surname,char* sex,int homeNum,int phoneNum,Adress* previous){
  Adress* new_address = (Adress*)malloc(sizeof(Adress));
  if(new_address==NULL){
    printf("\nThe dynamic alloction failed!\n");
    exit(1);
  }
  new_address->name = (char*)malloc(30*sizeof(char));
  if(new_address->name==NULL){exit(1);}
  new_address->surname = (char*)malloc(30*sizeof(char));
  if(new_address->surname==NULL){exit(1);}
  new_address->sex = (char*)malloc(sizeof(char));
  if(new_address->sex==NULL){exit(1);}
  strcpy(new_address->name, name);
  strcpy(new_address->surname, surname);
  strcpy(new_address->sex, sex);
  new_address->homeNumber = homeNum;
  new_address->phoneNumber = phoneNum;
  new_address->previous=previous;
  return new_address;
}

Adress* A_addAdress(Adress* a,Adress* address){
  if(a==NULL){
    a = address;
    return a;
  }
  a->previous=address;
  address->next=a;
  address->previous=NULL;
  return address;
}

void A_delete(Adress* a){
  if(a==NULL){
    return;
  }
  A_delete(a->next);
  free(a);
}

int A_inDatabase(Adress* a,char *name,char* surname){
  Adress* pf = a;
  for(pf=a;pf!=NULL;pf=pf->next){
    if(strcmp(pf->name, name)==0 && strcmp(pf->surname,surname)==0){
      return 1;
    }
  }
  return 0;
}

Adress* A_inputAdress(){
  char name[30];
  char surname[30];
  char sex[2];
  int phoneNum, homeNum;
  printf("Enter name: ");
  scanf("%s",name);
  getchar();
  printf("Enter surname: ");
  scanf("%s",surname);
  getchar();
  printf("Enter sex: ");
  scanf("%s",sex);
  getchar();
  printf("Enter phone number: ");
  scanf("%d",&phoneNum);
  printf("Enter home number: ");
  scanf("%d",&homeNum);
  Adress* new_address = A_new(name, surname, sex, homeNum,phoneNum, NULL);
  return new_address;
}

Adress* A_removeAdress(Adress* a,char* name, char* surname){
  if(a==NULL){
    printf("\nThe database is empty! (A_removeAdress)\n");
    return NULL;
  }
  if(A_inDatabase(a, name, surname)==0){
    printf("\nThere is no such address in the database!\n");
    return NULL;
  }
  if(strcmp(a->name, name)==0 && strcmp(a->surname,surname)==0){
    printf("\n%s %s removed successfully!\n",name,surname);
    return a->next;
  }
  Adress* pf = a;
  Adress* prev;
  while(pf!=NULL){
    if(strcmp(pf->name, name)==0 && strcmp(pf->surname,surname)==0){
      prev=pf->previous;
      printf("%s\n",prev->name);
      prev->next=pf->next;
    }
    pf=pf->next;
  }
  printf("\n%s %s removed successfully!\n",name,surname);
  return a;
}