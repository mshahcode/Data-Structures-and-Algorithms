#include <stdio.h>
#include <stdlib.h>
#include "Adress.h"

int main(void) { 
  
  char name[30];
  char surnameContact[30];
  int choice=1;
  Adress* database = NULL;
  Adress* new_address;
  while(choice!=4){
    printf("\n\nMAIN MENU\n\n");
    printf("1 - Enter a contact\n");
    printf("2 - Remove a contact\n");
    printf("3 - Show all contacts\n");
    printf("4 - QUIT\n\n");

    printf("\nYour choice: ");
    scanf("%d",&choice);

    switch(choice){
      case 1:
        new_address = A_inputAdress();
        database = A_addAdress(database,new_address);
        break;
      case 2:
        printf("Enter the name and the surname of a contact to be removed: ");
        scanf("%s %s",name,surnameContact);
        getchar();
        database = A_removeAdress(database, name, surnameContact);
        break;
      case 3:
        A_show(database);
        break;
      case 4:
        printf("Farewell!\n");
        break;
      default:
        printf("Please enter correct choices!\n");
        break;
    }
  }
  A_delete(database);
 
  return 0;
}